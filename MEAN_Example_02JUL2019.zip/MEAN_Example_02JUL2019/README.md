# User Details - MEAN Stack Application
Using Node JS, Express JS , Angular and Mongo DB I have been built this application.

## Prerequest : 
Need Node JS, Angular and Mongo DB.

### Before Running this Project
Install npm packages using 'npm install' command from server Folder.

#### Running this Project
1. To start the Server application using 'node index.js' command from server  Folder.
2. To start the Client application using 'ng serve' command from client  Folder.
3. Application URL : localhost:4200
##### Folder Structure

● MEAN Stack Application
+---● client
	+---● e2e
    |
    +---● node_modules
	|
    +---● src
		|
		+-- app
			+---● auth
			+---● shared
			+---● user
				+---● sign-in
				+---● sign-up
			+---● user-profile
			+---● userprofileedit
			+-- app.component.html
			+-- app.component.ts
			+-- app.module.ts
			+-- routes.ts
		+---● assets
		+---● environments
		+-- styles.css
|
|
|
+---● server
	+---● config  
		|
		+-- config.json
		+-- config.js
	|
	+---● controllers
		|
		+-- user.controller.js
	|
	+---● models
		|
		+-- user.model.js
		|
		+-- db.js
	|
	+---● node_modules
	|
	+---● routes
		|
		+-- index.router.js
	|
	+---● index 
	|
	+---● package.json
	|
	+---● package-lock.json
|
|
|
+---● README

###### PORT AND MONGODB URL

PORT and MONGODB URL maintained in config ---> config.json.
Based on that PORT, Change the API. Now currently i set 3001 as PORT Number.

####### Screen Details

# Sign-up:

In this screen the following fields are mandatory,

1.FirstName,
2.LastName,
3.Age,
4.Gender,
5.Mobile (Unique Key, Minimum and Maximum is 10 digits),
6.EmailId (Unique Key, Format Validation applied),
7.Password (Minimum 4 characters required)

## Sign-in:

In this screen the following fields are mandatory,

1.EmailId (Format Validation applied),
2.Password (Minimum 4 characters required).

######## Validations:
1.Mandatory Field Validation.
2.Email Id Format Validation.
3.Mobile Number - Minimum and Maximum Digits Validation.
4.Password - Minimum characters Validation.
5.Unique Key Validation for Mobile and Email Id.
6.jsonwebtoken - To generate JSON Web Token, to secure the API.
7.passport-local - Email and Password Validation.
8.bcryptjs - To secure the Password.(Encripted Password only stored in DataBase).


