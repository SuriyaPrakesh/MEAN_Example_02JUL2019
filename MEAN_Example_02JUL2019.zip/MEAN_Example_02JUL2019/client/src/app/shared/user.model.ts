export class User {
    FirstName: string;
    MiddleName: string;
    LastName: string;
    Age: number;
    Gender: string;
    Mobile: string;
    PhoneNo: string;
    EmailId: string;
    AddressLine1: string;
    AddressLine2: string;
    AddressLine3: string;
    PhotoPath: string;
    Password: string;
    CreatedBy: number;
    CreatedAt: Date;
    UpdatedBy: number;
    UpdatedAt: Date;
}
