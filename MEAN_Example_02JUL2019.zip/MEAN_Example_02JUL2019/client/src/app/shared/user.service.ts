import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";

import { User } from "./user.model";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  selectedUser: User = {
    FirstName: '',
    MiddleName: '',
    LastName: '',
    Age: 0,
    Gender: '',
    Mobile: '',
    PhoneNo: '',
    EmailId: '',
    AddressLine1: '',
    AddressLine2: '',
    AddressLine3: '',
    PhotoPath: '',
    Password: '',
    CreatedBy: 0,
    CreatedAt: null,
    UpdatedBy: 0,
    UpdatedAt: null
  }

  noAuthHeader = {headers: new HttpHeaders({ 'NoAuth' : 'True' })};

  constructor(private http: HttpClient) {
    this.selectedUser=<User>{};
  }

  postUser(user: User) {
    return this.http.post(environment.apiBaseUrl + '/register', user, this.noAuthHeader)
  }

  putUser(user: User) {
    return this.http.put(environment.apiBaseUrl + '/updateuserprofile', user)
  }

  login(authCredentials) {
    authCredentials.mobile = authCredentials.Mobile;
    authCredentials.email = authCredentials.EmailId;
    authCredentials.password = authCredentials.Password;
    return this.http.post(environment.apiBaseUrl + '/authenticate', authCredentials, this.noAuthHeader);
  }

  getUserProfile() {
    return this.http.get(environment.apiBaseUrl + '/userprofile');
  }

  setToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  deleteToken() {
    localStorage.removeItem('token');
  }

  getUserPayload() {
    var token = localStorage.getItem('token');
    if (token) {
      var userPayload = atob(token.split('.')[1]);
      return JSON.parse(userPayload);
    } else {
      return null;
    }
  }

  isLoggedIn() {
    var userPayload = this.getUserPayload();
    if (userPayload) {
      return userPayload.exp > Date.now() / 1000;
    } else {
      return false;
    }
  }
}
