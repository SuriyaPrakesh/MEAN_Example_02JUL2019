import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";

import { UserService } from "../shared/user.service";

@Component({
  selector: 'app-userprofileedit',
  templateUrl: './userprofileedit.component.html',
  styleUrls: ['./userprofileedit.component.css']
})
export class UserprofileeditComponent implements OnInit {
  showSuccessMessage: boolean;
  serverErrorMessage: string;
  userDetails;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.userService.getUserProfile().subscribe(
      res => {
        this.userService.selectedUser = res['user'];
      },
      err => {

      }
    )
  }

  onSubmit(form : NgForm) {
    this.userService.putUser(form.value).subscribe(
      res => {
          this.showSuccessMessage = true;
        setTimeout(() => {
          this.showSuccessMessage = false;
        }, 5000);
      },
      err => {
        if (err.status === 422) {
          this.serverErrorMessage = err.error.join('<br/>');
        } else {
          this.serverErrorMessage = 'Something wend wrong...';
        }
      }
    );
  }

  onLogout() {
    this.userService.deleteToken();
    this.router.navigate(['/signin']);
  }

}
