import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";

import { UserService } from "../shared/user.service";

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  userDetails;
  showSuccessMessage: boolean;
  serverErrorMessage: string;
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.userService.getUserProfile().subscribe(
      res => {
        this.userDetails = res['user'];
      },
      err => {

      }
    )
  }

  onLogout() {
    this.userService.deleteToken();
    this.router.navigate(['/signin']);
  }

  onUpdate() {
    this.router.navigateByUrl('/userprofileupdate');
  }

}
