import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";

import { UserService } from "../../shared/user.service";

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  showSuccessMessage: boolean;
  serverErrorMessage: string;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.selectedUser = {
      FirstName: '',
      MiddleName: '',
      LastName: '',
      Age: null,
      Gender: '',
      Mobile: '',
      PhoneNo: '',
      EmailId: '',
      AddressLine1: '',
      AddressLine2: '',
      AddressLine3: '',
      PhotoPath: '',
      Password: '',
      CreatedBy: 0,
      CreatedAt: null,
      UpdatedBy: 0,
      UpdatedAt: null
    };
  }

  onSubmit(form : NgForm) {
    this.userService.postUser(form.value).subscribe(
      res => {
        this.showSuccessMessage = true;
        setTimeout(() => {
          this.showSuccessMessage = false;
        }, 5000);
        this.resetForm(form);
      },
      err => {
        if (err.status === 422) {
          this.serverErrorMessage = err.error.join('<br/>');
        } else {
          this.serverErrorMessage = 'Something wend wrong...';
        }
      }
    );
  }

  resetForm(form: NgForm) {
    this.userService.selectedUser = {
      FirstName: '',
      MiddleName: '',
      LastName: '',
      Age: null,
      Gender: '',
      Mobile: '',
      PhoneNo: '',
      EmailId: '',
      AddressLine1: '',
      AddressLine2: '',
      AddressLine3: '',
      PhotoPath: '',
      Password: '',
      CreatedBy: 0,
      CreatedAt: null,
      UpdatedBy: 0,
      UpdatedAt: null
    };
    form.resetForm();
    this.serverErrorMessage = '';
  }

}
