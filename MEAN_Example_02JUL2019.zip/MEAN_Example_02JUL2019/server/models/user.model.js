const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

var UserSchema = new mongoose.Schema({
    FirstName: {
        type: String,
        required: 'Full Name Can Not Be Empty...'
    },
    MiddleName: {
        type: String
    },
    LastName: {
        type: String,
        required: 'Last Name Can Not Be Empty...'
    },
    Age: {
        type: Number,
        required: 'Age Can Not Be Empty...'
    },
    Gender: {
        type: String,
        required: 'Gender Can Not Be Empty...'
    },
    Mobile: {
        type: String,
        required: 'Mobile Can Not Be Empty...',
        unique: true
    },
    PhoneNo: {
        type: String
    },
    EmailId: {
        type: String,
        required: 'EmailId Can Not Be Empty...',
        unique: true
    },
    AddressLine1: {
        type: String
    },
    AddressLine2: {
        type: String
    },
    AddressLine3: {
        type: String
    },
    PhotoPath: {
        type: String
    },
    Password: {
        type: String,
        required: 'Password Can Not Be Empty...',
        minlength: [4, 'Password must be atleast 4 character long...']
    },
    SaltSecret: {
        type: String
    },
    CreatedBy:{
        type: Number
    },
    CreatedAt: {
        type: Date
    },
    UpdatedBy: {
        type: Number
    },
    UpdatedAt: {
        type: Date
    }
});

UserSchema.path('EmailId').validate((val) => {
    EmailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return EmailRegex.test(val);
}, 'Invalid Email Id...');

UserSchema.pre('save', function(next){
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(this.Password, salt, (err, hash) => {
            this.Password = hash;
            this.SaltSecret = salt;
            next();
        });
    });
});

UserSchema.methods.verifyPassword = function(Password) {
    return bcrypt.compareSync(Password, this.Password);
}

UserSchema.methods.generateJwt = function() {
    return jwt.sign({ _id: this._id, _FirstName: this.FirstName ,_Mobile: this.Mobile ,
        _MiddleName: this.MiddleName, _LastName: this.LastName, _Age: this.Age,
        _Gender: this.Gender, _PhoneNo: this.PhoneNo, _EmailId: this.EmailId,
        _AddressLine1: this.AddressLine1, _AddressLine2: this.AddressLine2, _AddressLine3: this.AddressLine3,
        _PhotoPath: this.PhotoPath }, process.env.JWT_SECRET,
    {
        expiresIn: process.env.JWT_EXP
    });
}

mongoose.model('User', UserSchema);