const mongoose = require('mongoose');
const passport = require('passport');
const _ = require('lodash');

const User = mongoose.model('User');


module.exports.register = (req, res, next) => {
    var user = new User();
    var currentDate = new Date();
    user.FirstName = req.body.FirstName;
    user.MiddleName = req.body.MiddleName;
    user.LastName = req.body.LastName;
    user.Age = req.body.Age;
    user.Gender = req.body.Gender;
    user.Mobile = req.body.Mobile;
    user.PhoneNo = req.body.PhoneNo;
    user.EmailId = req.body.EmailId;
    user.AddressLine1 = req.body.AddressLine1;
    user.AddressLine2 = req.body.AddressLine2;
    user.AddressLine3 = req.body.AddressLine3;
    user.PhotoPath = req.body.PhotoPath;
    user.Password = req.body.Password;
    user.SaltSecret = req.body.SaltSecret;
    user.CreatedBy = req.body.CreatedBy;
    user.CreatedAt = currentDate;
    user.UpdatedBy = req.body.UpdatedBy;
    user.UpdatedAt = currentDate;

    user.save((err, doc) => {
        if (!err) {
            res.send(doc);
        } else {
            if (err.code === 11000) {
                res.status(422).send(['Duplicate User Found...']);
            } else {
                return next(err);
            }
        }
    })
}

module.exports.updateUserProfile = (req, res, next) => {
    var currentDate = new Date();
    User.findByIdAndUpdate({ _id: req.body._id}, req.body, { new: true}, (err, doc) => {
        if (!err) {
            res.send(doc);
        } else {
            console.log(err);
            if (err.code === 11000) {
                res.status(422).send(['Duplicate User Found...']);
            } else {
                return next(err);
            }
        }
    })

}

module.exports.authenticate = (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return res.status(400).json(err);
        } else if (user) {
            return res.status(200).json({"token": user.generateJwt()});
        } else {
            return res.status(404).json(info);
        }
    })(req, res);
}

module.exports.userProfile = (req, res, next) => {
    User.findOne({ _id: req._id},
    (err, user) => {
        if (!user) {
            return res.status(404).json({ status: false, message: 'User Record Not Found...' });
        } else {
            return res.status(200).json({ status: true, user: _.pick(user, ['_id','FirstName', 'Mobile', 'EmailId', 'MiddleName',
            'LastName', 'Age', 'Gender', 'PhoneNo',
            'AddressLine1', 'AddressLine2', 'AddressLine3', 'PhotoPath']) });
        }
    });
}